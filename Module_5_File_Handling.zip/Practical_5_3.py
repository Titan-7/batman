# Practical 5.3

import shutil

# Define the source and destination file paths
source_file = "5(3)_1.txt"
destination_file = "5(3)_2.txt"

# Create a sample source file for demonstration
with open(source_file, 'w') as f:
    f.write("This is the content of the source file.\n")
    f.write("It will be copied to the destination file.")

# Use a try-except block to handle potential errors
try:
    shutil.copyfile(source_file, destination_file)
    print(f"Contents of '{source_file}' successfully copied to '{destination_file}'.")
except FileNotFoundError:
    print(f"Error: The file '{source_file}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
