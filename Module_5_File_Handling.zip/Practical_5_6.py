# Practical 5.6

def main():
    filename = input("Enter the name of the text file: ")

    try:
        with open(filename, 'r') as file:
            content = file.read()

            capitalized_content = ""
            for word in content.split():
                capitalized_content += word.capitalize() + " "

            print("Modified content:")
            print(capitalized_content.strip())

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

main()
