# Practical 5.1

def analyze_text(text, target_word=None, target_char=None):
    results = {}
    # Number of lines
    lines = text.splitlines()
    results['number_of_lines'] = len(lines)

    # Number of words
    words = text.split()  # Splits by whitespace
    results['number_of_words'] = len(words)

    # Number of blank spaces
    results['number_of_blank_spaces'] = text.count(' ')

    # Occurrence of particular word
    if target_word:
        results[f'occurrence_of_"{target_word}"'] = text.lower().count(target_word.lower())

    # Occurrence of particular character
    if target_char:
        results[f'occurrence_of_"{target_char}"'] = text.count(target_char)

    return results

# Example Usage:
sample_text = """This is a sample text.
It has multiple lines.
Let's count words, lines, and spaces.
Also, we'll check for specific words and characters."""

analysis_results = analyze_text(sample_text, target_word="text", target_char="s")

for key, value in analysis_results.items():
    print(f"{key}: {value}")
