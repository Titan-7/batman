# Practical 5.2

def append_to_file():
    """
    Reads a string from the user and appends it to a file.
    """
    try:
        # Get the string input from the user
        user_string = input("Please enter a string to append to the file: ")

        # Open the file in append mode ('a')
        # The 'with' statement ensures the file is automatically closed
        with open('5(2).txt', 'a') as file:
            # Append the user's string to the file, followed by a newline character
            file.write(user_string + '\n')
       
        print("Your string has been successfully appended to 'user_input.txt'.")

    except IOError as e:
        # Handle potential errors, such as file permission issues
        print(f"An error occurred: {e}")

append_to_file()
