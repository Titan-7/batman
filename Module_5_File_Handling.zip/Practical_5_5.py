# Practical 5.5

def main():
    source_filename = input("Enter the name of the source file (to read from): ")
    destination_filename = input("Enter the name of the destination file (to append to): ")

    try:
        with open(source_filename, 'r') as source_file:
            content_to_append = source_file.read()

        with open(destination_filename, 'a') as destination_file:
            destination_file.write(content_to_append)

        print(f"Contents of '{source_filename}' successfully appended to '{destination_filename}'.")
    except FileNotFoundError:
        print(f"Error: One of the files was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

main()
