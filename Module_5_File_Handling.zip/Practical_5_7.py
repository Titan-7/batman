# Practical 5.7

def read_file_in_reverse(filename):
    try:
        with open(filename, 'r') as file:
            content = file.read()  # Read the entire file content
            reversed_content = content[::-1]  # Reverse the content using slicing
            print(f"----Content of \"{filename}\" in Reverse Order----")
            print(reversed_content)
    except FileNotFoundError:
        print(f"\nError: The file '{filename}' was not found.")
    except Exception as e:
        print(f"\nAn error occurred: {e}")

file_name = input("Enter the file name: ")
read_file_in_reverse(file_name)
