# Practical 5.4

def main():
    filename = input("Enter the name of the text file: ")

    try:
        with open(filename, 'r') as file:
            content = file.read()

            current_number_str = ""
            found_numbers = []

            for char in content:
                if char.isdigit():
                    current_number_str += char
                else:
                    if current_number_str:
                        found_numbers.append(int(current_number_str))
                        current_number_str = ""

            if current_number_str:
                found_numbers.append(int(current_number_str))

            if found_numbers:
                print("Numbers found in the file:")
                for number in found_numbers:
                    print(number)
            else:
                print("No numbers found in the file.")

    except FileNotFoundError:
        print(f"Error: The file '{filename}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

main()
