# Practical 8.3

class Node:
    def __init__(self, data):
        # Initialize a new node with data and next pointer
        self.data = data
        self.next = None

def insert_at_beginning(head, data):
    new_node = Node(data)
    new_node.next = head
    return new_node

def insert_at_end(head, data):
    new_node = Node(data)
    if head is None:
        return new_node

    current = head
    while current.next:
        current = current.next

    current.next = new_node
    return head

def delete_after_node(node):
    if node is None or node.next is None:
        print("Error: The given node is None or the next node is None")
        return

    next_node = node.next
    node.next = next_node.next
    del next_node

def traverse(head):
    current = head
    while current:
        print(current.data, end=" -> ")
        current = current.next
    print("None")

head = None
head = insert_at_beginning(head, 3)
head = insert_at_beginning(head, 2)
head = insert_at_beginning(head, 1)
insert_at_end(head, 4)
delete_after_node(head.next)
traverse(head)
