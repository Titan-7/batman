# Practical 8.1

def linear_search(list, num):
    for i in list:
        if i == num:
            return list.index(i)
    else:
        return "Element not found"

def binary_search(list, num):
    low = 0
    high = len(list) - 1

    while low <= high:
        mid = (low + high) // 2
        if list[mid] == num:
            return mid
        elif list[mid] < num:
            low = mid + 1
        else:
            high = mid - 1

    return "Element not found"

arr = [1,2,3,4,5,6,7,8,9,10]
print(f"Linear Search(5): {linear_search(arr, 5)}")
print(f"Binary Search(5): {binary_search(arr, 5)}")
