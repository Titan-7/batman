# Practical 12 (Fixed No-Function Version)
# Draw Square, Rectangle, Star, Triangle, Pentagon, Hexagon, Octagon

import turtle

# Setup screen
screen = turtle.Screen()
screen.setup(width=900, height=800)
screen.bgcolor("white")

t = turtle.Turtle()
t.shape("turtle")
t.speed(5)
t.pensize(3)

# --- Square ---
t.penup()
t.goto(-300, 200)
t.pendown()
t.pencolor("green")
t.fillcolor("lightgreen")
t.begin_fill()
for _ in range(4):
    t.forward(100)
    t.right(90)
t.end_fill()

# --- Rectangle ---
t.penup()
t.goto(-100, 200)
t.pendown()
t.pencolor("purple")
t.fillcolor("plum")
t.begin_fill()
for _ in range(2):
    t.forward(150)
    t.right(90)
    t.forward(75)
    t.right(90)
t.end_fill()

# --- Star ---
t.penup()
t.goto(200, 200)
t.pendown()
t.pencolor("gold")
t.fillcolor("yellow")
t.begin_fill()
for _ in range(5):
    t.forward(120)
    t.right(144)
t.end_fill()

# --- Triangle ---
t.penup()
t.goto(-300, -50)
t.setheading(0)  # Ensure proper facing
t.pendown()
t.pencolor("blue")
t.fillcolor("lightblue")
t.begin_fill()
for _ in range(3):
    t.forward(120)
    t.left(120)
t.end_fill()

# --- Pentagon ---
t.penup()
t.goto(-50, -50)
t.setheading(0)
t.pendown()
t.pencolor("red")
t.fillcolor("salmon")
t.begin_fill()
for _ in range(5):
    t.forward(100)
    t.right(72)
t.end_fill()

# --- Hexagon ---
t.penup()
t.goto(200, -50)
t.setheading(0)
t.pendown()
t.pencolor("orange")
t.fillcolor("lightyellow")
t.begin_fill()
for _ in range(6):
    t.forward(90)
    t.right(60)
t.end_fill()

# --- Octagon ---
t.penup()
t.goto(50, -300)
t.setheading(0)
t.pendown()
t.pencolor("brown")
t.fillcolor("peachpuff")
t.begin_fill()
for _ in range(8):
    t.forward(70)
    t.right(45)
t.end_fill()

t.hideturtle()
turtle.done()
