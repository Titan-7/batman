# Practical 9.5

import re
def find_words_starting_with_a(text):
  pattern = r'\ba\w*'
  matches = re.findall(pattern, text)
  return matches

a = "apple banana apricot orange avocado"
print(f"In '{a}': {find_words_starting_with_a(a)}")
