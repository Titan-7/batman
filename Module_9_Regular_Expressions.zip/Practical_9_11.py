# Practical 9.11

import re

def find_words_starting_with_an_or_ak(text):
  pattern = r'\b(an|ak)\w*'
  matches = re.findall(pattern, text)
  return matches

a = "analyze the data and acknowledge the results aka answers"
print(f"In '{a}': {find_words_starting_with_an_or_ak(a)}")
