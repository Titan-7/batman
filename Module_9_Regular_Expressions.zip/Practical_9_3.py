# Practical 9.3

import re

def match_a_then_bbb(text):
  pattern = r'abbb'
  if re.search(pattern, text):
    return f"Match found in '{text}'"
  else:
    return f"No match found in '{text}'"

a = "aabbb"
b = "accc"

print(match_a_then_bbb(a))
print(match_a_then_bbb(b))
