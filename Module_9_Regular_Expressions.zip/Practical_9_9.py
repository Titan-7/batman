# Practical 9.9

import re

def find_single_digits(text):
  pattern = r'\d'
  matches = re.findall(pattern, text)
  return matches

a = "The price is $10.99 and we have 25 items in stock."
print(f"In '{a}': {find_single_digits(a)}")
