# Practical 9.10

import re

def find_last_word(text):
  pattern = r'\b\w+$'
  match = re.search(pattern, text)
  if match:
    return match.group(0)
  else:
    return "No word found at the end of the string."

a = "This is a sample string"

print(f"The last word in '{a}' is: {find_last_word(a)}")
