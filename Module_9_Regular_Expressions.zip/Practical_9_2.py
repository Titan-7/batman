# Practical 9.2

import re

def find_whitespace(text):
  pattern = r'\s'
  if re.search(pattern, text):
    return "Match found: The string contains a whitespace character."
  else:
    return "No match: The string does not contain a whitespace character."

a = "A quick brown fox jumps over the lazy river"
print(f"'{a}': {find_whitespace(a)}")
