# Practical 9.4

import re

def x(text):
  pattern = r'\bm..\b'
  matches = re.findall(pattern, text)
  return matches

a = "man cat dog mat mom"
print(f"In '{string1}': {x(a)}")
