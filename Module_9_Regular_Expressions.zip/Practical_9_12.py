# Practical 9.12

import re

def retrieve_dob(text):
  pattern = r'\b\d{2}[/-]\d{2}[/-]\d{4}\b'
  match = re.search(pattern, text)
  if match:
    return match.group(0)
  else:
    return "No DOB found in the specified format."

a = "The event is scheduled for 10-01-2023."
print(f"In '{a}': {retrieve_dob(a)}")
