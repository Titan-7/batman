# Practical 9.8

import re

def find_three_four_five_char_words(text):
  pattern = r'\b\w{3,5}\b'
  matches = re.findall(pattern, text)
  return matches

a = "a quick brown fox jumps over the lazy dog"
print(f"In '{a}': {find_three_four_five_char_words(a)}")
