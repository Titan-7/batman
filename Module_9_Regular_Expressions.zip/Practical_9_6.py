# Practical 9.6

import re

def x(text):
  pattern = r'\b\d\w*'
  matches = re.findall(pattern, text)
  return matches

a = "There are 10 apples and 5 oranges."
print(f"In '{a}': {x(a)}")
