# Practical 9.7

import re

def find_five_char_words(text):
  pattern = r'\b\w{5}\b'
  matches = re.findall(pattern, text)
  return matches

a = "a quick brown fox jumps over the lazy dog"
print(f"In '{a}': {find_five_char_words(a)}")
