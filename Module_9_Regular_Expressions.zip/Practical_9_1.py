# Practical 9.1

def check_string(text):
  return text.startswith("The ") and text.endswith("Indus")

a = "The best university of ahmedabad award goes to Indus"
b = "A quick brown fox jumps over the lazy river"

print(f"'{a}' starts with 'The ' and ends with 'Indus': {check_string(a)}")
print(f"'{b}' starts with 'The ' and ends with 'Indus': {check_string(b)}")
