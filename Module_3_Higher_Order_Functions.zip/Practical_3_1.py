# Practical 3.1

check_value = lambda val, group: val in group

print("3 -> [1, 5, 8, 3] :", check_value(3, [1, 5, 8, 3]))
print("-1 -> [1, 5, 8, 3] :", check_value(-1, [1, 5, 8, 3]))
