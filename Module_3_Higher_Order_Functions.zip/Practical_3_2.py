# Practical 3.2

ends_with_char = lambda s, ch: s.endswith(ch)

print(ends_with_char("hello", "o"))
print(ends_with_char("world", "r"))
