# Practical 3.3

L = [3, 4, 6, 9, 11]

is_prime = lambda n: all(n % i != 0 for i in range(2, int(n ** 0.5) + 1)) and n > 1

L = list(map(lambda x: 'P'
if is_prime(x)
else 'NP', L))
print("Output:", L)
