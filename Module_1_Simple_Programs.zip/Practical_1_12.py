# Practical 1.12

import os
import platform

os_name = os.name

platform_info = platform.system()

release_info = platform.release()

print("Operating System Name:", os_name)
print("Platform:", platform_info)
print("Release Information:", release_info)
