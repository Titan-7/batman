# Practical 1.6

a = int(input("Enter the value of A: "))
print(a)
if a%2 == 0:
  print("A is Even")
else:
  print("A is odd")
