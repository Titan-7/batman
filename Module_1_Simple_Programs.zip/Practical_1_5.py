# Practical 1.5

# prompt: Create a menu driven program to show various operators supported by python.

def show_arithmetic_operators():
    a = 10
    b = 3
    print("Arithmetic Operators:")
    print(f"{a} + {b} = {a + b}")
    print(f"{a} - {b} = {a - b}")
    print(f"{a} * {b} = {a * b}")
    print(f"{a} / {b} = {a / b}")
    print(f"{a} % {b} = {a % b}")
    print(f"{a} ** {b} = {a ** b}")
    print(f"{a} // {b} = {a // b}")

def show_comparison_operators():
    a = 10
    b = 20
    print("\nComparison Operators:")
    print(f"{a} == {b} is {a == b}")
    print(f"{a} != {b} is {a != b}")
    print(f"{a} > {b} is {a > b}")
    print(f"{a} < {b} is {a < b}")
    print(f"{a} >= {b} is {a >= b}")
    print(f"{a} <= {b} is {a <= b}")

def show_logical_operators():
    a = True
    b = False
    print("\nLogical Operators:")
    print(f"{a} and {b} is {a and b}")
    print(f"{a} or {b} is {a or b}")
    print(f"not {a} is {not a}")

def show_assignment_operators():
    a = 10
    print("\nAssignment Operators:")
    print(f"Initial value of a: {a}")
    a += 5
    print(f"a += 5: {a}")
    a -= 3
    print(f"a -= 3: {a}")
    a *= 2
    print(f"a *= 2: {a}")
    a /= 4
    print(f"a /= 4: {a}")
    a %= 3
    print(f"a %= 3: {a}")

def show_bitwise_operators():
    a = 10 # Binary: 1010
    b = 4  # Binary: 0100
    print("\nBitwise Operators:")
    print(f"{a} & {b} = {a & b}")
    print(f"{a} | {b} = {a | b}")
    print(f"{a} ^ {b} = {a ^ b}")
    print(f"~{a} = {~a}")
    print(f"{a} << 2 = {a << 2}")
    print(f"{a} >> 2 = {a >> 2}")

def show_identity_operators():
    x = [1, 2, 3]
    y = [1, 2, 3]
    z = x
    print("\nIdentity Operators:")
    print(f"x is z: {x is z}")
    print(f"x is y: {x is y}")
    print(f"x is not y: {x is not y}")

def show_membership_operators():
    my_list = [1, 2, 3, 4, 5]
    print("\nMembership Operators:")
    print(f"3 in my_list: {3 in my_list}")
    print(f"6 in my_list: {6 in my_list}")
    print(f"6 not in my_list: {6 not in my_list}")

def main_menu():
    while True:
        print("\n--- Python Operators Menu ---")
        print("1. Arithmetic Operators")
        print("2. Comparison Operators")
        print("3. Logical Operators")
        print("4. Assignment Operators")
        print("5. Bitwise Operators")
        print("6. Identity Operators")
        print("7. Membership Operators")
        print("8. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            show_arithmetic_operators()
        elif choice == '2':
            show_comparison_operators()
        elif choice == '3':
            show_logical_operators()
        elif choice == '4':
            show_assignment_operators()
        elif choice == '5':
            show_bitwise_operators()
        elif choice == '6':
            show_identity_operators()
        elif choice == '7':
            show_membership_operators()
        elif choice == '8':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")

main_menu()
