# Practical 1.9

first_name = input('Please enter first name:')
last_name = input('Please enter last name:')
print(last_name,first_name)
