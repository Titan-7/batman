# Practical 1.3

import numpy as np

vector_a = np.array([1, 2, 3])
vector_b = np.array([4, 5, 6])
vector_add = vector_a + vector_b
vector_mul = np.dot(vector_a, vector_b)

matrix_a = np.array([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
])
matrix_b = np.array([
    [7, 8, 9],
    [4, 5, 6],
    [1, 2, 3]
])

matrix_add = matrix_a + matrix_b
matrix_mul = np.dot(matrix_a, matrix_b)
print("The addition of vectors is:", vector_add)
print("The multiplication (dot product) of vectors is:", vector_mul)
print("The addition of matrices is:\n", matrix_add)
print("The multiplication of matrices is:\n", matrix_mul)
