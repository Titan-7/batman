# Practical 1.7

sum = 0
for i in range(15):
    sum += i
print(f"The sum of first 15 number is: {sum}")
