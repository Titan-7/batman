# Practical 1.11

def check_value_in_list(value, values):
    return value in values

test_data_1 = [1, 5, 8, 3]
test_data_2 = 1
test_data_3 = -1

result_1 = check_value_in_list(test_data_2, test_data_1)
result_2 = check_value_in_list(test_data_3, test_data_1)

print(f"Is {test_data_2} in {test_data_1}: {result_1}")
print(f"Is {test_data_3} in {test_data_1}: {result_2}")
