# Practical 1.4

str1 = "Indus UNiversity!"
string_length = len(str1)
print(f"Length of the string '{str1}': {string_length}")


new_list = list(str1)
new_list[7] = 'n'
print(f"Original string: {str1}, Modified string: {new_list}")

def is_palindrome(s):
  s = s.replace(" ", "").lower()
  return s == s[::-1]

string1 = "madam"
print(f"'{string1}' is a palindrome: {is_palindrome(string1)}")

string_part1 = "Hello "
concatenated_string = string_part1 + str1
print(f"Concatenated string: {concatenated_string}")
