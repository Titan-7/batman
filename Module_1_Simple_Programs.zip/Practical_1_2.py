# Practical 1.2

import numpy as np

vector1 = np.array([1, 2, 3])
vector2 = np.array([4, 5, 6])
vector_sum = vector1 + vector2
print("Vector Addition:", vector_sum)

vector_product = vector1 * vector2
print("Vector Multiplication (Element-wise):", vector_product)

matrix1 = np.array([[1, 2], [1, 2],])
matrix2 = np.array([[3, 4], [1, 2]])
matrix_sum = matrix1 + matrix2
print("\nMatrix Addition:\n", matrix_sum)

matrix_product = np.dot(matrix1, matrix2)
print("\nMatrix Multiplication:\n", matrix_product)
