# Practical 15.2

import tensorflow as tf

tensor1 = tf.constant(3, dtype=tf.int32)
tensor2 = tf.constant(5, dtype=tf.int32)

tensor_sum = tf.add(tensor1, tensor2)

print(f"Tensor 1: {tensor1}")
print(f"Tensor 2: {tensor2}")
print(f"Sum of tensors: {tensor_sum.numpy()}")
