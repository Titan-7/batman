# Practical 6.10

def count_even_odd(numbers):
    even_count = 0
    odd_count = 0
    even_numbers = []
    odd_numbers = []

    for number in numbers:
        if number % 2 == 0:
            even_count += 1
            even_numbers.append(number)
        else:
            odd_count += 1
            odd_numbers.append(number)

    print(f"Even numbers: {even_numbers}")
    print(f"Odd numbers: {odd_numbers}")
    print(f"Total number of even = {even_count}, Total number of odd = {odd_count}")
    
numbers = [21, 22, 35, 36, 40]
count_even_odd(numbers)
