# Practical 6.1

def create_list_and_tuple():

    numbers_str = input("Enter a sequence of comma-separated numbers: ")
    numbers_list = numbers_str.split(",")
    numbers_tuple = tuple(numbers_list)

    print("List:", numbers_list)
    print("Tuple:", numbers_tuple)

if __name__ == "__main__":
    create_list_and_tuple()
