# Practical 6.8

def create():
    return {input("Enter id: "): input("Enter name: ") for _ in range(int(input("How many elements? ")))}

def update(d, k, v): 
    print("Updated." if d.update({k: v}) else "Key not found.")

def append(d, k, v):
    if k not in d: d[k] = v; print("Appended.")
    else: print("Key exists.")

def delete(d): d.clear(); print("Dictionary deleted.")

def delete_key(d, k):
    print("Deleted." if d.pop(k, None) else "Key not found.")

def sort_dict(d): 
    d = dict(sorted(d.items()))
    print("Sorted:", d)
    return d

def main():
    d = {}
    menu = {
        '1': lambda: create(),
        '2': lambda: update(d, input("Key to update: "), input("New value: ")) if d else print("Create first."),
        '3': lambda: append(d, input("Key: "), input("Value: ")) if d else print("Create first."),
        '4': lambda: delete(d) if d else print("Nothing to delete."),
        '5': lambda: delete_key(d, input("Key to delete: ")) if d else print("Create first."),
        '6': lambda: sort_dict(d) if d else print("Create first."),
        '7': lambda: print("Length:", len(d)) if d else print("Create first."),
        '8': lambda: print("Dictionary:", d) if d else print("Create first.")
    }

    while True:
        print("\nMenu:\n1.Create\n2.Update\n3.Append\n4.Delete All\n5.Delete Key\n6.Sort\n7.Length\n8.Display\n9.Exit")
        c = input("Choice: ")
        if c == '1':
            d = create(); print("Created:", d)
        elif c in menu:
            result = menu[c]()
            if c == '6' and result: d = result  # update sorted dict
        elif c == '9':
            print("Exiting..."); break
        else:
            print("Invalid choice.")

main()
