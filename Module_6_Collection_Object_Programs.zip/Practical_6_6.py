# Practical 6.6

def create_list():
    return [int(input("Enter element: ")) 
for _ in range(int(input("Number of elements: ")))]

def show_menu():
    print("\nMenu:\n1.Create\n2.Update\n3.Append\n4.Delete All\n5.Delete One\n6.Sort\n7.Length\n8.Exit")

def operations():
    my_list = create_list()
    while True:
        show_menu()
        try:
            c = int(input("Choice: "))
        except:
            print("Invalid input."); continue

        if c == 1:
            my_list = create_list()
        elif c == 2:
            i = int(input("Index to update: "))
            if 0 <= i < len(my_list):
                my_list[i] = int(input("New value: "))
            else: print("Invalid index.")
        elif c == 3:
            my_list.append(int(input("Element to append: ")))
        elif c == 4:
            my_list.clear()
            print("List deleted.")
        elif c == 5:
            e = int(input("Element to delete: "))
            if e in my_list: my_list.remove(e)
            else: print("Element not found.")
        elif c == 6:
            my_list.sort()
        elif c == 7:
            print("Length:", len(my_list))
        elif c == 8:
            print("Exiting."); break
        else:
            print("Invalid choice.")
        print("List:", my_list)

operations()
