# Practical 6.9

class NumberChecker:
    def __init__(self):
        self.even_numbers = []
        self.odd_numbers = []
    def check_and_store(self, number):
        if number % 2 == 0:
            self.even_numbers.append(number)
            print(f"{number} is even.")
        else:
            self.odd_numbers.append(number)
            print(f"{number} is odd.")
    def print_results(self):
        print("Even numbers:", self.even_numbers)
        print("Odd numbers:", self.odd_numbers)

def main():
    checker = NumberChecker()
    n = int(input("Enter the number of elements: "))
    for _ in range(n):
        num = int(input("Enter a number: "))
        checker.check_and_store(num)
    checker.print_results()

if __name__ == "__main__":
    main()
