# Practical 6.4

list_1 = set(["White", "Black", "Red"])
list_2 = set(["Red", "Green"])
print(list_1)
print(list_2)

print("list of color which are not present in list 2")
new_set = list_1.difference(list_2)
print(new_set)
