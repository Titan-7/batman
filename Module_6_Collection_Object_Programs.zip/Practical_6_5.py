# Practical 6.5

square_dict = {}
for num in range(1, 16):
    square = num ** 2
    square_dict[num] = square
print(square_dict)
