# Practical 6.3

list = ["PSC -> ", "Module 6 -> ", "Practical 6.3"]
str = ' '.join(list)
print("Concatenated String: ", str)

