# Practical 6.7

def set_operations():
    my_set = set()
    while True:
        print("\nMenu:\n1.Create\n2.Update\n3.Append\n4.Clear\n5.Delete Element\n6.Sort\n7.Length\n8.Exit")
        choice = input("Enter your choice: ")

        if choice == '1' or choice == '2' or choice == '3':
            element = input("Enter element: ")
            my_set.add(element)
            print("Updated Set:", my_set)

        elif choice == '4':
            my_set.clear()
            print("Set cleared:", my_set)

        elif choice == '5':
            element = input("Enter element to delete: ")
            if element in my_set:
                my_set.remove(element)
                print("Element removed:", my_set)
            else:
                print("Element not found.")

        elif choice == '6':
            print("Sorted Set:", sorted(my_set))

        elif choice == '7':
            print("Length of set:", len(my_set))

        elif choice == '8':
            print("Exiting...")
            break

        else:
            print("Invalid choice.")

set_operations()
