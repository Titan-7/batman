# Practical 6.2

def create_list_and_print_first_and_last_by_both_indexing():

  numbers_str = input("Enter a sequence of comma-separated colors: ")
  numbers_list = numbers_str.split(",")
  list_length = len(numbers_list)
  print("By 1 Indexing method: ")
  print("first: ", numbers_list[0], "last: ", numbers_list[list_length - 1])
  print("By -1 Indexing method: ")
  print("first: ", numbers_list[-(list_length)], "last: ", numbers_list[-1])

if __name__ == "__main__":
  create_list_and_print_first_and_last_by_both_indexing()
