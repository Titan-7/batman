# Practical 10.2

import threading
import time

def print_numbers():
    for i in range(1, 6):
        print(f"Number Thread: {i}")
        time.sleep(0.5)

def print_letters():
    for letter in ['A', 'B', 'C', 'D', 'E']:
        print(f"Letter Thread: {letter}")
        time.sleep(0.7)

thread_numbers = threading.Thread(target=print_numbers)
thread_letters = threading.Thread(target=print_letters)

print("Starting Threads...")

thread_numbers.start()
thread_letters.start()

thread_numbers.join()
thread_letters.join()

print("All threads finished. Program exiting.")
