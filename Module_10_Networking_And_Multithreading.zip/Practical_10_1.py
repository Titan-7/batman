# Practical 10.1

# 10.10.1
# Sever.py
import socket
import threading
import sys

IP_ADDRESS = '127.0.0.1'
PORT = 5555

def handle_client(connection_object, client_address):
    print(f"SERVER: Connection established with {client_address}")

    try:
        connection_object.sendall(b"Welcome to the Chat Server! Type 'stop' to disconnect.")

        while True:
            data_receive = connection_object.recv(1024)

            if not data_receive or data_receive.decode('utf-8').strip().lower() in ['stop', 'quit']:
                print(f"SERVER: Client {client_address} requested disconnect.")
                break

            client_message = data_receive.decode('utf-8')
            print(f"CLIENT: {client_message}")

    except ConnectionResetError:
        print(f"SERVER: Client {client_address} forcibly closed the connection.")
    except Exception as e:
        print(f"SERVER ERROR: {e}")
    finally:
        connection_object.close()
        print(f"SERVER: Connection with {client_address} closed.")
        sys.exit()

def start_server():
    server_object = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_object.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
        server_object.bind((IP_ADDRESS, PORT))
        server_object.listen(1)
        print(f"SERVER: Listening on {IP_ADDRESS}:{PORT}")

        connection_object, client_address = server_object.accept()

        handle_client(connection_object, client_address)

    except socket.error as e:
        print(f"SERVER: Could not start server: {e}")
    except KeyboardInterrupt:
        print("\nSERVER: Shutting down.")
    finally:
        server_object.close()

if __name__ == '__main__':
    start_server()


#
