# Practical 4

# merged_module.py
def get_numbers():
    """
    Prompts the user to enter two numbers and returns them as floats.
    """
    while True:
        try:
            num1 = float(input("Enter the first number: "))
            num2 = float(input("Enter the second number: "))
            return num1, num2
        except ValueError:
            print("Invalid input. Please enter valid numbers.")

def perform_operations(num1, num2):
    """
    Performs addition, subtraction, and multiplication on two numbers
    and prints the results.
    """
    addition = num1 + num2
    subtraction = num1 - num2
    multiplication = num1 * num2

    print(f"\nResults:")
    print(f"Addition: {num1} + {num2} = {addition}")
    print(f"Subtraction: {num1} - {num2} = {subtraction}")
    print(f"Multiplication: {num1} * {num2} = {multiplication}")

# main_program.py
from merged_module import (get_numbers, perform_operations)

if __name__ == "__main__":
    print("Welcome to the Arithmetic Operations Program!")
    number1, number2 = get_numbers()
    perform_operations(number1, number2)
    print("\nProgram finished.")
