# Practical 13.6

import numpy as np
categories = np.array(['Banana', 'Mango', 'Apple', 'Graps', 'Watermelon'])
values = np.array([23, 45, 56, 12, 39])
print("Categories:", categories)
print("Values:", values)

import matplotlib.pyplot as plt
plt.figure(figsize=(8, 6))
plt.bar(categories, values, color='#008ac5') # Changed bar color to yellowish
plt.xlabel("Fruits")
plt.ylabel("Sales")
plt.title("Bar Plot of Total Sales ")
plt.show()
