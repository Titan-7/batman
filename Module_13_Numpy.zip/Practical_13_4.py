# Practical 13.4

import numpy as np

array1 = np.array([1, 2, 3, 2, 3, 4, 3, 4, 5, 6])
array2 = np.array([7, 2, 10, 2, 7, 4, 9, 4, 9, 8])

common_items = np.intersect1d(array1, array2)
print("Common items:", common_items)
