# Practical 13.2

import numpy as np
# Using numpy and np.where to replace odd numbers with -1
numbers_np = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
replaced_array = np.where(numbers_np % 2 != 0, -1, numbers_np)
print("Array with odd numbers replaced by -1:", replaced_array)
