# Practical 13.1

import numpy as np
# Using numpy and np.where
numbers_np = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
odd_numbers_np = numbers_np[np.where(numbers_np % 2 != 0)]
print(odd_numbers_np)
