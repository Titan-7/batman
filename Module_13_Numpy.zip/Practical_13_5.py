# Practical 13.5

import numpy as np
matrix_a = np.array([[1, 2], [3, 4]])
matrix_b = np.array([[5, 6], [7, 8]])

matrix_product_np = np.dot(matrix_a, matrix_b) # Matrix multiplication
print("NumPy Matrix A:\n", matrix_a)
print("NumPy Matrix B:\n", matrix_b)
print("NumPy Matrix Multiplication (using np.dot):\n", matrix_product_np)
