# Practical 13.3

import numpy as np

one_d_array = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
two_d_array = one_d_array.reshape(2, 5)

print("Original 1D array:", one_d_array)
print("Converted 2D array (2x5):\n", two_d_array)
