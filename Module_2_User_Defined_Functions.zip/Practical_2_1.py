# Practical 2.1

def power(x, y=2):
    return x ** y

print(power(5))
print(power(2, 3))
print(power(7, 1))
