# Practical 2.3

def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

fib_func = fibonacci

def print_fibonacci_series(terms):
    print("Fibonacci series:")
    for i in range(terms):
        print(fib_func(i), end=" ")

n = int(input("Enter number of terms: "))
print_fibonacci_series(n)
