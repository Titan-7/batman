# Practical 11.2

import tkinter as tk
from tkinter import ttk

def show_selected_city():
    selected_city = city_var.get()
    result_label.config(text="Selected City: " + selected_city)

# Create the main window
root = tk.Tk()
root.title("City Selector")

# List of cities
cities = ["Ahmedabad", "Baroda", "Delhi", "Mumbai", "Surat"]

# Variable to store the selected city
city_var = tk.StringVar(root)
city_var.set(cities[0]) # Set the default value

# Create the dropdown menu
city_dropdown = ttk.OptionMenu(root, city_var, cities[0], *cities)
city_dropdown.pack(pady=10)

# Create a button to show the selected city
select_button = tk.Button(root, text="Show Selected City", command=show_selected_city)
select_button.pack()

# Create a label to display the selected city
result_label = tk.Label(root, text="Selected City: ")
result_label.pack(pady=10)

# Run the main loop
root.mainloop()
