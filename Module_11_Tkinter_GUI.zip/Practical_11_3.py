# Practical 11.3

import tkinter as tk
from PIL import Image, ImageTk

root = tk.Tk()
root.title("Image Display")
root.geometry("800x600")

try:
    pil_image = Image.open("image.png")
    tk_image = ImageTk.PhotoImage(pil_image)
    image_label = tk.Label(root, image=tk_image)
    image_label.image = tk_image
    image_label.pack(pady=20)
except FileNotFoundError:
    error_label = tk.Label(root, text="Error: Image file not found!", fg="red", font=("Arial", 16))
    error_label.pack(pady=50)
except Exception as e:
    error_label = tk.Label(root, text=f"An error occurred: {e}", fg="red", font=("Arial", 16))
    error_label.pack(pady=50)

root.mainloop()
