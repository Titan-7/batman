# Practical 11.4

import tkinter as tk

def register():
    username = username_entry.get()
    password = password_entry.get()
    print(f"Registered user: {username}, Password: {password}")
    # You can add code here to save the registration details

# Create the main window
root = tk.Tk()
root.title("Registration Form")

# Create labels and entry fields for username and password
username_label = tk.Label(root, text="Username:")
username_label.pack(pady=5)
username_entry = tk.Entry(root, width=30)
username_entry.pack(pady=5)

password_label = tk.Label(root, text="Password:")
password_label.pack(pady=5)
password_entry = tk.Entry(root, show="*", width=30) # show="*" hides the password
password_entry.pack(pady=5)

# Create a registration button
register_button = tk.Button(root, text="Register", command=register)
register_button.pack(pady=10)

# Run the main loop
root.mainloop()
