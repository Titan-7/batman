# Practical 11.1

import tkinter as tk
def evaluate_expression():
    try:
        result = eval(entry.get())
        result_label.config(text="Result: " + str(result))
    except Exception as e:
        result_label.config(text="Error: " + str(e))

# Create the main window
root = tk.Tk()
root.title("Simple Calculator")

# Create an entry widget for input
entry = tk.Entry(root, width=30)
entry.pack(pady=10)

# Create a button to evaluate the expression
evaluate_button = tk.Button(root, text="Evaluate", command=evaluate_expression)
evaluate_button.pack()

# Create a label to display the result
result_label = tk.Label(root, text="Result: ")
result_label.pack(pady=10)

# Run the main loop
root.mainloop()
