# Practical 7.2

class Parent:
    def my_method(self):
        print("This is the parent's method.")

class Child(Parent):
    def my_method(self):
        print("This is the child's overridden method.")

    def call_parent_method(self):
        # Overcoming overriding using super()
        super().my_method()

print("--- Method Overriding ---")
parent_obj = Parent()
parent_obj.my_method()

child_obj = Child()
child_obj.my_method()  # This calls the overridden method in the Child class

print("\n--- Overcoming Overriding using super() ---")
child_obj.call_parent_method()
