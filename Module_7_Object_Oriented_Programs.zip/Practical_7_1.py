# Practical 7.1

# 1. Single Inheritance
class Parent:
    def func1(self):
        print("This is a function from the Parent class.")
class Child(Parent):
    def func2(self):
        print("This is a function from the Child class.")
print("--- Single Inheritance ---")
child_obj = Child()
child_obj.func1()
child_obj.func2()

# 2. Multiple Inheritance
class Father:
    def father_method(self):
        print("This is the father's method.")
class Mother:
    def mother_method(self):
        print("This is the mother's method.")
class Son(Father, Mother):
    def son_method(self):
        print("This is the son's method.")
print("\n--- Multiple Inheritance ---")
son_obj = Son()
son_obj.father_method()
son_obj.mother_method()
son_obj.son_method()

# 3. Multilevel Inheritance
class Grandfather:
    def grandfather_method(self):
        print("This is the grandfather's method.")
class Father_ml(Grandfather):
    def father_method_ml(self):
        print("This is the father's method (multilevel).")
class Son_ml(Father_ml):
    def son_method_ml(self):
        print("This is the son's method (multilevel).")
print("\n--- Multilevel Inheritance ---")
son_ml_obj = Son_ml()
son_ml_obj.grandfather_method()
son_ml_obj.father_method_ml()
son_ml_obj.son_method_ml()

# 4. Hybrid Inheritance (Combination of multiple and multilevel inheritance)
class A:
    def method_a(self):
        print("Method from class A")
class B(A):
    def method_b(self):
        print("Method from class B")
class C(A):
    def method_c(self):
        print("Method from class C")
class D(B, C):
    def method_d(self):
        print("Method from class D")
print("\n--- Hybrid Inheritance ---")
d_obj = D()
d_obj.method_a()
d_obj.method_b()
d_obj.method_c()
d_obj.method_d()
