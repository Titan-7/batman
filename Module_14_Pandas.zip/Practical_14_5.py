# Practical 14.5

import pandas as pd
import matplotlib.pyplot as plt
data = {
    "Race": ["Race 1", "Race 2", "Race 3"],
    "Ferrari": [25, 18, 15],
    "McLaren": [18, 25, 12],
    "Mercedes": [15, 12, 25],
}

df = pd.DataFrame(data)
df.set_index("Race", inplace=True)
print("F1 - Race Points (Ferrari / McLaren / Mercedes)")
print(df)
print()

totals = df.sum()
print("F1 - Total Points Summary")
print(totals)
print()

plt.figure(figsize=(8, 5))
totals.plot(kind="bar", color=["red", "orange", "silver"])
plt.title("Formula 1 - Total Points (Ferrari, McLaren, Mercedes)")
plt.xlabel("Team")
plt.ylabel("Total Points")
plt.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.7)
plt.tight_layout()
plt.show()
