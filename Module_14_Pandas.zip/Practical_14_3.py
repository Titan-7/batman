# Practical 14.3

import pandas as pd

ingredients_data = {
    'Flour': '4 cups',
    'Milk': '1 cup',
    'Eggs': '2 large',
    'Spam': '1 can'
}

ingredients = pd.Series(ingredients_data, name='Dinner')

print('\n--- Ingredients Series ---')
print(ingredients)
