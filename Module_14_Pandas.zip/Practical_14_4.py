# Practical 14.4

import pandas as pd
from google.colab import files

print("Please upload the 'winemag-data-130k-v2.csv' file.")
uploaded = files.upload()

file_name = 'winemag-data-130k-v2.csv'

try:
    df = pd.read_csv(file_name, index_col=0)

    print("Row number 25:")
    display(df.iloc[24])

    print("\nColumn number 13:")
    display(df.iloc[:, 12].head())

    print("\nRows where country name = France:")
    display(df[df['country'] == 'France'].head())

    print("\nRecords where province=Michigan and taster_name=Alexander Peartree:")
    display(df[(df['province'] == 'Michigan') & (df['taster_name'] == 'Alexander Peartree')].head())

    print("\nDescription of the DataFrame:")
    display(df.describe())

except FileNotFoundError:
    print(f"Error: The file '{file_name}' was not found. Please make sure you have uploaded it.")
except Exception as e:
    print(f"An error occurred: {e}")
