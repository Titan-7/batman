# Practical 14.1

data = {
    'Apples': [30],
    'Bananas': [21]
}

fruits = pd.DataFrame(data)

print(fruits)
